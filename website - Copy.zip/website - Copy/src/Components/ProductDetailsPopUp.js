import React from "react";
import styled from "styled-components";

const PopupOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`;

const PopupContent = styled.div`
  display: flex;
  background: white;
  border-radius: 5px;
  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.2);
  max-width: 80%;
  max-height: 80%;
  overflow: hidden;
`;

const CloseButton = styled.button`
  position: absolute;
  top: 25px;
  right: 25px;
  background: none;
  border: none;
  color: white;
  font-size: 2.2rem;
  cursor: pointer;
`;

const ImagesContainer = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 20px;
`;

const ImagesRow = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
`;

const ProductImage = styled.img`
  width: 40%; /* Set width to occupy almost half of the container */
  max-height: 200px;
  border-radius: 5px;
`;

const TextContainer = styled.div`
  display: flex;
  flex-direction: column;
  text-align:center;
  justify-content: space-between;
  padding: 20px;
`;

const ProductDetailsPopup = ({ product, onClose }) => {
  return (
    <PopupOverlay>
      <PopupContent>
        <CloseButton onClick={onClose}>&times;</CloseButton>
        <ImagesContainer>
          <ImagesRow>
            <ProductImage src={product.image1} alt={product.name} />
            <ProductImage src={product.image2} alt={product.name} />
          </ImagesRow>
          <ProductImage src={product.image3} alt={product.name} />
        </ImagesContainer>
        <TextContainer>
          <div>
            <h2>{product.name}</h2>
            <p>{product.description}</p>
          </div>
          <div>
            <p>Weight: {product.weight} kg</p>
            <p>Capacity: {product.capacity} units</p>
          </div>
        </TextContainer>
      </PopupContent>
    </PopupOverlay>
  );
};

export default ProductDetailsPopup;
