import React, { useState } from 'react';
// import './infrastruture.css';
import Footer from "./Footer";
import Navbar from './Navbar';
import { InfoSharp } from '@mui/icons-material';

const imageUrls = [
  "/image/bending_machine.jpg",
  '/image/cnc_machine_1.jpg',
  '/image/cnc_machine_2.jpg',
  '/image/fiber_laser_cutting.jpg',
  '/image/flasma_cutting.jpg',
  '/image/heat_chamber.jpg',
  '/image/iron_cutting.jpg',
  '/image/laser_cutting_1.jpg',
  '/image/lathe_machine.jpg',
  '/image/powder_coating.jpg',
  '/image/powder_sprayer.jpg',
  '/image/rool_bending.jpg',
  '/image/vmc_machine.jpg',
];

const imageNames = [
  "Bending Machine",
  "CNC Machine 1",
  "CNC Machine 2",
  "Fiber Laser Cutting",
  "Plasma Cutting",
  "Heat Chamber",
  "Iron Cutting",
  "Laser Cutting 1",
  "Lathe Machine",
  "Powder Coating",
  "Powder Sprayer",
  "Roll Bending",
  "VMC Machine",
];

const infrastructureText = (
  <div>
    <Navbar/>

    <div className='content'>
    <h1 style={{ color: 'black' }}>Infrastructure</h1>
    <br></br>
    <p style={{ color: 'black' }}>There was heavy demand in the spare parts for the Areca dehusking machines we manufacture. At initial stages, we were purchasing all the essential spare parts from outside i.e., Bangalore based companies. By virtue of which, there existed difficulty and delay in manufacturing machines, even all the spare parts were unavailable at one place. Even servicing process for the machines were also affected by aforementioned reasons resulting in frustration among customers.</p>
    <br></br>
    <p style={{ color: 'black', marginBottom: '20px' }}></p>
    <p style={{ color: 'black' }}>Sensing these hardships, the founder of our company, Mr. Vishwanath, decided to manufacture all the spare parts in our company, to solve this problem. He visited several foreign countries and purchased high-end technological machines which resulted in manufacturing spare parts required for our machines in our own backyard. This increased our quality and productivity thereby increasing customer satisfaction. Also, we can give spare-parts needed for the customers without any delay.</p>
    <br></br>
    </div>
    </div>
);

function Infrastructure() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const handleNextClick = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex + 1) % imageUrls.length);
  };
  const handlePrevClick = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === 0 ? imageUrls.length - 1 : prevIndex - 1
    );
  };

  return (
    <div style={{ color: 'black' }}>
      
      {infrastructureText}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <button className="prev-button" onClick={handlePrevClick} style={{ marginRight: '10px' }}>&#8249;</button>
        <img src={imageUrls[currentImageIndex]} alt={`Image ${currentImageIndex + 1}`} />
        <button onClick={handleNextClick} className="next-button" style={{ marginLeft: '10px' }}>&#8250;</button>
      </div>
      <p style={{ textAlign: 'center', color: 'black' }}>{imageNames[currentImageIndex]}</p>
      <br></br>
      <br></br>
      <Footer />
    </div>
  );
}

export default Infrastructure;