import React from 'react';
import './Your.css'; // Import your CSS file
import Navbar from './Navbar';
import Footer from './Footer';

const YourComponent = () => {
  return (
    <div>
        <Navbar/>
        <div className="About-containera">

    
    <div>
        <h1>V-TECH GROUP OF COMPANIES</h1>
      <div className="infog">
        
        <p>
        <h2> Kuntavalli Industries Private Limited</h2><p>
We aim to manufacture construction equipment and provide them to customers in economic price. Also, V-Tech is working diligently to provide customers with various machines.</p>
        </p>
        <br/>
        <br/>
      </div>
      <div className="image-containerg">
        <div className="image-description-containerg">
            <h2>V-Tech Auto-Motors</h2>
          <img className='Imgg' src="/Img/bike_2.jpg" alt="Motor Bike" />
          <p>The dream of our director Kuntavalli Vishwanath to manufacture electric vehicle and make it available for the common people is accomplished. Eco friendly and people friendly v-tech vechiles are sound free and other environmental pollution free and is more suitable for the current weather weather situation.

Introducing electric vehicle with superior quality battery at affordable price.

Also introducing electric auto and electric car, which is expected to be in the market very soon.</p>
          
        </div>
        <div className="image-description-containerg">
        <h2>Dumper</h2>
          <img className='Imgg' src="/Img/dumper.jpg" alt="Image 2" />
          <p>Provides automatic hydraulic lifting and also manual lifting as per need.<br/>

Motor Capacity : (any of your 100cc / 120cc / 200cc motor vechile.)<br/>

Gear : Forward 4 gear / Reverse 4 gear.<br/>

Weight lifting capacity : 400 - 500 Kg.</p>
        </div>
        
        <div className="image-description-containerg">
        <h2>Earth Agar</h2>
          <img className='Imgg' src="/Img/earth_auger.jpeg" alt="Image 2" />
          <p>We attach the earth agar/digger to the tractors which is used to dig holes for electric poles / pits for plants.</p>
        </div>
        <div className="image-description-containerg">
        <h2>Ibbani Food Industries</h2>
          <img className='Imgg' src="/Img/food.jpg" alt="Image 2" />
          <p>We are introducing the famous foods of malenadu like jackfruit papad, savoury foods from banana, aloo and rice, varity of pickles, chakli, kodubale, chutneypudi, mixtures, rasam powder and Sambhar powder, and many more delicious food items that are prepared hygienically to the market.</p>
        </div>
        <div className="image-description-containerg">
        <h2>Generator</h2>
          <img className='Imgg'  src="/Img/generator.jpg" alt="Image 2" />
          <p>According to customer's need and requirement, we manufacture and design 5KV - 12KV soundless generators with top-notch quality. The generator is inexpensive, eco-friendly, safe, has better efficiency, efficient fuel usage, low maintenance cost and easily serviceable.</p>
        </div>
        <div className="image-description-containerg">
        <h2>V-Tech and Food Beverages</h2>
          <img className='Imgg'  src="/Img/ibbani.jpg" alt="Image 2" />
          <p>We have started 'Ibbani', a pure water supply unit which is successfully serving people since 2013. Ibbani has gained appreciation from people all over karnataka because of its quality. The water quality is tested by our experts in a fully furnished chemical and microbiological lab. We use state-of the-art machinery to convert the superior quality raw materials, preform to bottles of 300ml, 500ml, 1L, 2L and 20L water and we also ensure that the quality adheres to ISI standards.</p>
        </div>
        <div className="image-description-containerg">
        <h2>Mini Excavator</h2>
          <img className='Imgg' src="/Img/mini-excavators.jpg" alt="Image 2" />
          <p>This is designed with farmer friendly perspective, that is suitanle for the agriculture and available at a reasonable price for the customers.</p>
        </div>
        <div className="image-description-containerg">
        <h2>Mini Road-Roller</h2>
          <img className='Imgg' src="/Img/mini-roller.jpg" alt="Image 2" />
          <p>We are manufacturing low maintenance double drum roller with easy steering, useful in road works and other miscellaneous work.</p>
        </div>
        <div className="image-description-containerg">
        <h2>Sharp Excavator</h2>
          <img className='Imgg' src="/Img/sharp_excavator.jpg" alt="Image 2" />
          <p>We use best-grade spare parts to manufacture sharp excavators that are of exceptional quality, power and available to customers at a reasonable price. This machine is agro friendly i.e, very useful for agricultural and other works.</p>
        </div>
        {/* Add more image descriptions here */}
      </div>
    </div>
    <Footer/>
    </div>
    </div>
    
  );
};

export default YourComponent;

