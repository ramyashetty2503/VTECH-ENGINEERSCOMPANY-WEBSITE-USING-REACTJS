import React from 'react';
import Footer from "./Footer"
import Navbar from './Navbar';
const About =() => {
  return (
    <div>
        <Navbar/>
    <div className="About-containera">
    {/* <div className="background-image"></div> */}
    <div className="contenta">
      <h1>In a Nutshell About Company</h1>
      <p>V-Tech Engineers which is proud company of Malenadu and Karnataka state hails from Kuntavalli village which comes under Melige gram panchayat of Thirthahalli taluk of Shivamogga district, the district popularly known as Cradle of Malenadu.
      </p>
      <p style={{ marginBottom: '10px' }}></p>
      <h1>The Glorious Journey From The Roots</h1>
      <p style={{ marginBottom: '10px' }}></p>
      <p>In the region of malenadu, Farmers found their livelihood in the Arecanut crop. But as the years passed, the problems slowly started growing up and farmers who are completely depending on the crop got more bitter than sweet. At first, the problems faced by small and medium scale landowners/farmers was scarcity of labours for processing of Arecanut. Also adding to their woes was the fluctuation in the rates of Arecanut. These all slowly resulted in giving up mindset of farmers, since there was no appropriate rate for the crop grown. Young people who were witnessing this, started moving towards cities, from villages. This increased complications in the homes of the cultivators.
      </p>
      <p style={{ marginBottom: '10px' }}></p>
      <p>K. Vishwanath, who predominantly hails from agriculture family, carefully observed all these predicaments, he was determined to find full stop for the same and started working towards Arecanut dehusking machine right from the days of his studies in the year 2001-02. He received lot of criticism, obstacles in the initial stages of innovation. He was so tenacious that he didn’t look at anything other than his main motto of helping the farmers to overcome their problems. He worked round the clock to achieve his goal, visited cultivator's home often to finetune his creation and finally delivered Arecanut dehusking machine which is of great quality and beneficial to farmers.
      </p>
      <p style={{ marginBottom: '10px' }}></p>
      <p>Vishwanath, who had his interests in various domains, found purity of water of river Tunga [as said in puranas, Ganga snana, Tunga paana] is sky-high and with the intention of spreading the taste of the water across the country, established “Ibbani” which is pure water supplying Industry. It has its own fame and demand, popular across the state.</p>
      <p style={{ marginBottom: '10px' }}></p>
      <p>V-Tech Engineers company, which got Accreditation from government of India in the year 2007, haven’t restricted themselves to Arecanut dehusking machine, but have spread their horizons by successfully inventing Arecanut bunch separator, Gorabalu polisher, Pepper separating machines and several more farmer-friendly and farmer-centric products.
      </p>
      <p style={{ marginBottom: '20px' }}></p>
      <p>Numerous people have started their own business in the rural regions. For those kinds of people, getting imported equipment was only through some import companies in the big cities. Vishwanath, who will be travelling to foreign countries to buy the basic machineries for his company, scrutinized the circumstances and brought in the machineries which were needed for the functioning of such rural business. With the intention of encouraging people having such rural business, he established “Kuntavalli Industries Private Limited” (KIPL) and got the import licenses for it. Through the company, he not only imported the equipment needed for his company but also imported construction equipment from abroad, modified it according to the local market needs and sold to the needy people, thereby started the process of Trading. Responsibility of delivering the needed equipment to the people on-time lies on our company. Since, Vishwanath himself has technical knowledge on machines, he has made sure that imported machineries are defect-proof.</p>
      <p style={{ marginBottom: '20px' }}></p>
      <p>We recently established “Ibbani food industries” (IFI) with the objective of reaching out Malenadu food varieties which has demand across the state for its purity. Several tasty recipes prepared using vegetables and fruits grown through organic farming are introduced into the market with the name “Malenadu Ibbani”.</p>
      <p style={{ marginBottom: '20px' }}></p>
      <p>With the purpose of reducing the pollution and its ill effects on human health, investing all his education experience into the advantage, we have taken a stride ahead and have established a public limited company called “V-Tech Auto Motors Limited” which manufactures pollution free, battery-driven vehicles. In the first stage of it, two wheelers have been manufactured and is in the phase of getting green signal from vehicle department of Government for the sale.
      </p>
      <p style={{ marginBottom: '20px' }}></p>
      <p>In the continued part of inventing agriculture-centric products, Arecanut-Tree climbing machine invention is in progress by our company founder, Vishwanath. It will be available to the society in few days at inexpensive rate.</p>
      <p style={{ marginBottom: '20px' }}></p>
      <p>Our company started with 1 employee but now its giving employment to around 150 people thereby reducing the Unemployment rate in the rural areas and its credits goes to none other than Vishwanath and his dreams.
      </p>
      <p style={{ marginBottom: '20px' }}></p>
      <p>As a result of this, the percentage of young people shifting to cities for employment has seen a reduction rate and the same set of people who are working in our company has been successfully serving our company and spending some of their time happily on agriculture fields. Vishwanath is content about his precious contribution for the society.</p>
      <p style={{ marginBottom: '20px' }}></p>
      <p>Likewise, by not restricting themselves into single domain and spreading their roots in providing solution to all the basic problems and facilities of the people, V-Tech Engineers has successfully completed 12 years.</p>
      <p style={{ marginBottom: '20px' }}></p>
      <h1>Achievements of Kuntavalli Vishwanath in the field of Agriculture</h1>
      <p style={{ marginBottom: '10px' }}></p>
      <ul>
        <li>Invented Arecanut Dehusking machine during college days itself, which was the need of the hour of every Arecanut farmers.</li>
        <p style={{ marginBottom: '10px' }}></p>
        <li>From 2001 till 2007, after continuous development, revisions, providing new touch to the dehusking machine, the brand new and efficient machine manufacturing started in the year 2007.</li>
        <p style={{ marginBottom: '10px' }}></p>
        <li>First Unit was started beside his own house in the native of the inventor himself which is very small village called Kuntavalli. The Unit is successfully running till date due to invention and addition of various new machines regularly.</li>
        <p style={{ marginBottom: '10px' }}></p>
        <li>The unit was inaugurated by Honourable Former Chief Minister Late Sri S. Bangarappa. As a result of demo across the districts, taluk and all over the state, the machine has turned into boon for both the Karnataka state and other state farmers and thereby demand for the machine has increased significantly.</li>
        <p style={{ marginBottom: '10px' }}></p>
        <li>Achieved admirations as Youngest Techie in agriculture field, which is a result of interest towards invention from childhood. </li>
        <p style={{ marginBottom: '10px' }}></p>
        <li>Determination and encouragement of his father who strives for providing modernity in the field of Agriculture.</li>
        <p style={{ marginBottom: '10px' }}></p>
        <li>Complete support from Mother and Wife for further inventions.</li>
        <p style={{ marginBottom: '10px' }}></p>
        <li>Currently company is providing employment to around 60 literate and Illiterate young people. </li>
        <p style={{ marginBottom: '10px' }}></p>
        <li>All the employees of this factory are provided with free food and shelter.</li>
        <p style={{ marginBottom: '10px' }}></p>
        <li>Along with this, Company has started tipper fabrication unit.</li>
        <p style={{ marginBottom: '10px' }}></p>
        <li>In the process of Inventing the machines which will do the job of sprinkling the medicine to the Arecanut trees and separate the Arecanut bunches from the Arecanut trees, which is in great need for the farmers.</li>
        <p style={{ marginBottom: '10px' }}></p>
        <li>Despite lot of power cuts in the village area, the progress of the unit is increasing day by day and in vision with building new machineries, to increase the manufacturing output of the machines and various other purposes, new building for the factory is built and is inaugurated by Honourable Member of Parliament Sir B.Y. Raghavendra.</li>
        <p style={{ marginBottom: '10px' }}></p>
        <li>Great Personalities have given the support and encouragements to him, seeing the demo of the machine which is invented</li>
      </ul>
    </div>
    <Footer/>
    </div>
    </div>
  );
};

export default About;