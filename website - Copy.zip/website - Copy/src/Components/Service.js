import React from 'react';
import Footer from './Footer';
import Navbar from './Navbar';
// import './Services.css';

const servicesData = [
  {
    
    heading: 'Services',
    items: [
      'Arecanut, which is part of life of people of malenadu from century had numerous problems.',
      'There were lot of hardships than peace for the Arecanut farmers. Even variation in price contributed for it, which gave false promise of happiness to the farmers but ended in disappointment.',
      'Amidst of all these, V-Tech Engineers company stood as a ray of hope for farmers. Serving farmers is our main motto.',
      'Every customer primarily thinks of service for the machine even before purchasing it. Understanding it, we have established 24 hours open customer care centres in Thirthahalli town. As a result of which, we are successfully able to serve the farmers at any time they contact us.',
      'We are providing discount to every farmer in one or other way, who buys machines from our company.',
      'Providing machines at reasonable price and with superior quality is our strength.',
      'Farmers commonly do Arecanut related work during evening time. At that time, if any problem arises in the machine and if any farmer complains about it to our customer care, we have given immediate support to resolve it irrespective of time limit.',
      'Regularly, we take suggestions from farmers about their needs and modify the machines accordingly.',
      'Also, we will develop our machines accordingly which suits characteristics of the Arecanut grown in different regions.',
      'Apart from all these, if farmers face difficulty in transporting the machines bought from us, we voluntarily arrange transport facility for them at less cost and if in case, they have purchased variety of products, we will provide free transportation facility for those products.',
      'Not limiting ourselves only to Arecanut dehusking machine, we have invented several machines which are agriculture friendly and farmer friendly namely, Dumper, Arecanut Mat (Tray), pulley cart, Pepper threshing machine. Also, we have modified several machines according to the needs of farmers thereby assisting them.',
    ],
  },
  {
    heading: 'Other Service',
    items: [
      'There are many instances of providing installation services to farmers living in places where vehicle movement is impossible.',
      'Our goal is not just the sale of the machines, but giving complete information about the machine, performing installation and demonstration service to each customer who buys our machine. This is one of our main service.',
      'Providing 3 free service coupons along with the purchase of each machine by the farmers for their benefit is our primary purpose.',
      'Whether the problem is small or big, if a farmer complains about the machine, an expert will visit the place to resolve the problem is what we believe in and have been continuously doing it.',
      'We are establishing our emergency resolution team all over the state sensing the need.',
      'As an evidence for our excellent service, there is increase of our customers each year.',
    ],
  },
];

const Service = () => {
  return (
    <div>
          <Navbar/>

      <div className="Service-containers">
        <div className="contents">
          {servicesData.map((service, index) => (
            <div key={index}>
        
              <h1>{service.heading}</h1>
              <ul>
                {service.items.map((item, itemIndex) => (
                  <li key={itemIndex}>{item}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Service;
