import React from "react";

const LanguageOptions = () => {
  return (
    <div className="language-options">
      <li><a href="/Contact">Kannada</a></li>
      <li><a href="/Contact">English</a></li>
      {/* Add more language options as needed */}
    </div>
  );
};

export default LanguageOptions;
