import React from "react";

const MoreOptions = () => {
  return (
    <div className="more-options">
      <li><a href="/Group">V-TECH Group of companies</a></li><br/>
      <li><a href="/Awards">Awards and Achievements</a></li><br/>
      <li><a href="/Infra">Infrastructure</a></li>
      {/* Add more language options as needed */}
    </div>
  );
};

export default MoreOptions;