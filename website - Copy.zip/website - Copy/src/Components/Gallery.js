import React, { useState } from "react";
import styled from "styled-components";
import Navbar from "./Navbar";
import Footer from "./Footer";
import { Link } from "react-router-dom";


const products = [
  {
    id: 1,
    category: "exhibition",
    image1: "/Images/exhibition/hosanagara_1.jpg",
  },
  {
    id: 2,
    category: "exhibition",
    image1: "/Images/exhibition/hosanagara_2.jpg",
  },
  {
    id: 3,
    category: "exhibition",
    image1: "/Images/exhibition/puttur_1.jpg",
  },
  {
    id: 4,
    category: "exhibition",
    image1: "/Images/exhibition/puttur_2.jpg",
  },
  {
    id: 5,
    category: "exhibition",
    image1: "/Images/exhibition/puttur_3.jpg",
  },
  {
    id: 6,
    category: "exhibition",
    image1: "/Images/exhibition/puttur_4.jpg",
  },
  {
    id: 7,
    category: "exhibition",
    image1: "/Images/machines/bending_machine.jpg",
  },
  {
    id: 8,
    category: "exported",
    image1: "/Images/machines/cnc_machine_1.jpg",
  },
  {
    id: 9,
    category: "exported",
    image1: "/Images/machines/cnc_machine_2.jpg",
  },
  {
    id: 10,
    category: "exported",
    image1: "/Images/machines/fiber_laser_cutting.jpg",
  },
  {
    id: 11,
    category: "exported",
    image1: "/Images/machines/flasma_cutting.jpg",
  },
 
  {
    id: 12,
    category: "exported",
    image1: "/Images/machines/iron_cutting.jpg",
  },
  {
    id: 13,
    category: "exported",
    image1: "/Images/machines/laser_cutting_1.jpg",
  },
  {
    id: 14,
    category: "exported",
    image1: "/Images/machines/laser_cutting_2.jpg",
  },
  {
    id: 15,
    category: "exported",
    image1: "/Images/machines/lathe_machine.jpg",
  },
  {
    id: 16,
    category: "exported",
    image1: "/Images/machines/powder_coating.jpg",
  },
  {
    id: 17,
    category: "exported",
    image1: "/Images/machines/powder_sprayer.jpg",
  },
  {
    id: 18,
    category: "exported",
    image1: "/Images/machines/rool_bending.jpg",
  },
  {
    id: 19,
    category: "programs",
    image1: "/Images/programs/belagavi.jpg",
  },
  {
    id: 20,
    category: "programs",
    image1: "/Images/programs/koppa_1.jpg",
  },
  {
    id: 21,
    category: "programs",
    image1: "/Images/programs/koppa_2.jpg",
  },
  {
    id: 22,
    category: "programs",
    image1: "/Images/programs/vtech_stamp.jpg",
  },
];

const ImagePopup = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.8);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
`;

const PopupImage = styled.img`
  max-width: 80%;
  max-height: 80%;
  border-radius: 5px;
`;

const CloseButton = styled.button`
  position: absolute;
  top: 20px;
  right: 20px;
  background: none;
  border: none;
  color: white;
  font-size: 24px;
  cursor: pointer;
`;

const ProductCard = styled.div`
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 20px;
  margin: 10px;
  width: 300px;
  box-shadow: 0px 8px 10px rgba(1, 5, 6, 0.5);
  transition: transform 0.3s ease;

  &:hover {
    transform: scale(1.05);
  }
`;

const ProductImage = styled.img`
  max-width: 100%;
  height: auto;
  border-radius: 5px;
  cursor: pointer;
`;

const ProductContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  max-width: 2500px;
`;

const ButtonsContainer = styled.div`
  display: flex;
  justify-content: center;
  margin: 20px 0;
`;

const Button = styled.button`
  background-color: ${(props) => (props.selected ? "#007bff" : "transparent")};
  color: ${(props) => (props.selected ? "#fff" : "#007bff")};
  border: 1px solid #007bff;
  border-radius: 5px;
  padding: 10px 20px;
  margin: 0 10px;
  cursor: pointer;
`;

const Products = () => {
  const [selectedProductCategory, setSelectedProductCategory] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [isPopupVisible, setPopupVisible] = useState(false);

  const openProductDetails = (product) => {
    setSelectedProduct(product);
    setPopupVisible(true); // Show the popup when clicking an image
  };

  const closeProductDetails = () => {
    setSelectedProduct(null);
    setPopupVisible(false); // Hide the popup when closing
  };

  return (
    <div>
      <Navbar/>
      <div className="About-containera">

    <div className="home-container">
      <div>
        <br />
        <h1>Product List</h1>
        <br />
        <ButtonsContainer>
          <Button selected={selectedProductCategory === null} onClick={() => setSelectedProductCategory(null)}>
            All
          </Button>
          <Button selected={selectedProductCategory === "exported"} onClick={() => setSelectedProductCategory("exported")}>
            Exported Machines
          </Button>
          <Button selected={selectedProductCategory === "exhibition"} onClick={() => setSelectedProductCategory("exhibition")}>
            Exhibition
          </Button>
          <Button selected={selectedProductCategory === "programs"} onClick={() => setSelectedProductCategory("programs")}>
            Programs
          </Button>
        </ButtonsContainer>
        <ProductContainer>
          {products.map((product) => {
            if (selectedProductCategory === null || product.category === selectedProductCategory) {
              return (
                <ProductCard key={product.id}>
                  <ProductImage
                    src={product.image1}
                    alt={product.name}
                    onClick={() => openProductDetails(product)}
                  />
                </ProductCard>
              );
            }
            return null;
          })}
        </ProductContainer>
      </div>
      {isPopupVisible && (
        <ImagePopup>
          <PopupImage
            src={selectedProduct ? selectedProduct.image1 : ""}
            alt={selectedProduct ? selectedProduct.name : ""}
          />
          <CloseButton onClick={closeProductDetails}>Close</CloseButton>
        </ImagePopup>
      )}
      <Footer />
      </div>
    </div>
    </div>
  );
};

export default Products;