import React, { useState } from "react";
import styled from "styled-components";
import ProductDetailsPopup from "./ProductDetailsPopUp";
import Navbar from "./Navbar";
import Footer from "./Footer";

const products = [
  {
    id: 1,
    name: "Areca De-Husking Machine 1",
    image1: "/Images/V1_1.jpg",
    image2:"/Images/V1_left.jpg",
    image3:"/Images/V1_right.jpg",
    
    weight: "Per Hour:75 KG",
    capacity:"Capacity : 1 HP"

   
  },
  {
    id: 2,
    name: "Areca De-Husking Machine 2",
    image1: "/Images/V2_1.jpg",
    image2:"/Images/V2_1.jpg",
    image3:"/Images/V2_1.jpg",
    
    weight: "Per Hour:125",
    capacity:"Capacity : 1 HP"
    
  },
  {
    id: 3,
    name: "Areca De-Husking Machine 4",
    image1: "/Images/V4_1.jpg",
    image2:"/Images/V4_1.jpg",
    image3:"/Images/V4_1.jpg",
    
    weight: "Per Hour:210 KG",
    capacity:"Capacity : 2 HP"
    
  },
  {
    id: 4,
    image1: "/Images/V6_1.jpg",
    name: "Areca De-Husking Machine 6",
    image2:"/Images/V6_1.jpg",
    image3:"/Images/V6_1.jpg",
    weight: "Per Hour:370 KG",
    capacity:"Capacity : 2 HP"
    
  },
  {
    id: 5,
    name: "Areca De-Husking Machine 8",
    image1: "/Images/V8_1.jpg",
    image2:"/Images/V8_1.jpg",
    image3:"/Images/V8_1.jpg",
    weight: "Per Hour : 450 KG",
    capacity:"Capacity : 3 HP"

  },
  {
    id: 6,
    name: "Boiler",
    image1: "/Images/boiler.jpg",
    image2:"/Images/boiler.jpg",
    image3:"/Images/boiler.jpg",
    weight: "We will manufacture the customised tanks to boil de-husked areca nuts.",
    capacity:""

  },
 
  {
    id: 7,
    name: "Arecanut Bunch Remover",
    image1: "/Images/bunch_remover.jpg",
    image2:"/Images/bunch_remover.jpg",
    image3:"/Images/bunch_remover.jpg",
    weight: "Motor Capacity    :1 HP (200 - 220V)",
    capacity:"Result : Has the capacity to separate 100 bunches per hour (Depends on the bunch and skill of labour)."
    
  },
  {
    id: 8,
    name: "Dumper",
    image1: "/Images/dumper_1.jpg",
    image2:"/Images/dumper_1.jpg",
    image3:"/Images/dumper_1.jpg",
    weight: "Motor Capacity :  Depending on the Vehicle: 100cc/120cc/200cc/300cc.",
    capacity:" Weighing Capacity : 400 to 500KG.",
  },
  {
    id: 9,
    name: "Earth Aauger",
    image1: "/Images/earth_auger.jpeg",
    image2:"/Images/earth_auger.jpeg",
    image3:"/Images/earth_auger.jpeg",
    weight: "We attach the earth agar/digger to the tractors which is used to dig holes for electric poles / pits for plants.",
    capacity:""
  },
  {
    id: 10,
    name: "Generator",
    image1: "/Images/generator_1.jpg",
    image2:"/Images/generator_1.jpg",
    image3:"/Images/generator_1.jpg",
    weight: " we manufacture and design 5KV - 12KV soundless generators with top-notch quality. The generator is inexpensive, eco-friendly, safe, has better efficiency, efficient fuel usage, low maintenance cost.",
    capacity:""
    
  },
  {
    id: 11,
    name: "Gorabalu Polisher",
    image1: "/Images/gorabalu_polisher.jpg",
    image2:"/Images/gorabalu_polisher.jpg",
    image3:"/Images/gorabalu_polisher.jpg",
    weight: " Motor Capacity : 1 HP (200 - 220V)",
    capacity:"Stainless steel disk and drum and Powder coated metal Body."
    
  },
  {
    id: 12,
    name: "Pepper Treshing Machine",
    image1: "/Images/pepper_decorning.jpg",
    image2:"/Images/pepper_decorning.jpg",
    image3:"/Images/pepper_decorning.jpg",
    weight: " Motor Capacity : 1 HP (200 - 220v).",
    capacity:" Result : 40 to 45 KG per hour."
    
  },
  {
    id: 13,
    name: "Pulla Cart",
    image1: "/Images/pulla_cart.jpg",
    image2:"/Images/pulla_cart.jpg",
    image3:"/Images/pulla_cart.jpg",
    weight: "Capacity : 50 KG - 100 KG.",
    capacity:"Easy to move goods and unload it."
    
  },
  {
    id: 14,
    name: "Areca Nut Mat(Tray)",
    image1: "/Images/tray.jpg",
    image2:"/Images/tray.jpg",
    image3:"/Images/tray.jpg",
    weight: "This is a multipurpose mat which can be used for drying boiled areca nuts and also for other miscellaneous things.",
    capacity:""
    
  },
  
];
const PageContainer = styled.div`
  background-color: #f8f8f8;

`;

const ProductContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  margin-top: px;
  padding: 20px;
  display: grid;
  grid-template-columns: repeat(4, 1fr); /* 4 products per row */
  grid-gap: 50px; /* Add horizontal and vertical gap between products */
`;

const Heading = styled.h1`
  font-size: 1rem;
  font-weight: bold;
  text-align: center;
  margin-bottom: 2px;
  color: #333; /* Adjust the color as needed */
`;

const ProductCard = styled.div`
  background-color: white;
  
  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
  padding: 20px;
  text-align: center;
  width: 100%; /* Ensure all product cards have the same width */
  transition: transform 0.2s ease-in-out; /* Add a transition for smooth hover effect */
  cursor: pointer;

  &:hover {
    transform: scale(1.05); /* Scale the product card on hover */
  }
`;

const ProductImage = styled.img`
  max-width: 100%;
  height: auto;
  width: 100%; /* Ensure all images have the same width */
  height: 200px; /* Set a fixed height for the images (adjust as needed) */
`;

const ProductName = styled.h2`
  font-size: 0.9rem;
  margin: 0;
  color: rgb(82, 45, 150);
`;

const ProductDescription = styled.p`
  font-size: 1rem;
  color: rgb(82, 45, 150);;
`;

const Button = styled.button`
  background-color: #ccc; /* Change to your desired button background color */
  color: black; /* Change to your desired button text color */
  border:1.5px solid rgb(33, 28, 116);
  box-shadow:0px 0px 10px rgba(1, 2, 3, 0.2);
  margin-top:10px;
  padding: 10px 20px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 1rem;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #0056b3; /* Change to the hover color you want */
  }
`;


const Products = () => {
  const [selectedProduct, setSelectedProduct] = useState(null);

  const openProductDetails = (product) => {
    setSelectedProduct(product);
  };

  const closeProductDetails = () => {
    setSelectedProduct(null);
  };

  return (
    <PageContainer>
      <Navbar />
      <Heading>
        Below is the list of economical and efficient Arecanut Dehusking machines invented by V-Tech Engineers and machines
        which are newly invented by the company as per the needs of the farmers
      </Heading>
      <ProductContainer>
        {products.map((product) => (
          <ProductCard key={product.id} onClick={() => openProductDetails(product)}>
            <ProductImage src={product.image1} alt={product.name} />
            <ProductName>{product.name}</ProductName>
            <ProductDescription>{product.description}</ProductDescription>
            <Button onClick={() => openProductDetails(product)}>Details</Button>
          </ProductCard>
        ))}
      </ProductContainer>
      {selectedProduct && (
        <ProductDetailsPopup product={selectedProduct} onClose={closeProductDetails} />
      )}
      <Footer />
    </PageContainer>
  );
};

export default Products;