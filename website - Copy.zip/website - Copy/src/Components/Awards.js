import React, { useState } from 'react';
import './Awards.css';
import Footer from './Footer';
import Lightbox from 'react-image-lightbox';
import 'react-image-lightbox/style.css';
import Navbar from './Navbar';

const imagesData = [
  
  {
    src: '/Images/awards/corona_innovation.jpg',
    name: '“Corona Innovation Award” from Yuva Brigade 5th Pillar"',
  },
  {
    src: '/Images/awards/JNNCE.jpg',
    name: '“Most Promising Award” from KTES 2020, JNNCE',
  },
  {
    src: '/Images/awards/amith_sha.jpg',
    name: '“Abhimana Sanmaana” from Amit Shah',
  },
  {
    src: '/Images/awards/Post_office.jpg',
    name: 'Felicitation from Indian Post Office',
  },
  {
    src: '/Images/awards/Rameshwara_sanman.jpg',
    name: 'Felicitation from Rameshwara Co-operative Society',
  },
  {
    src: '/Images/awards/ujwala_udyami.jpg',
    name: 'Receiving “Ujwala Udyami 2019” award',
  },
  {
    src: '/Images/awards/Belagavi_Sahitya_sammelana.jpg',
    name: 'Felicitation from Sahitya Sammelana',
  },
  {
    src: '/Images/awards/chalagara.jpg',
    name: 'Receiving “Ujwala Udyami 2019” award',
  },
  {
    src: '/Images/awards/Fifth_piller.jpg',
    name: 'The Fifth Pillar',
  },
  {
    src: '/Images/awards/Sahyadri_Polytechnic_College.jpg',
    name: 'Sahyadri Polytechnic College teachers day and Engineers day recognition',
  },
  {
    src: '/Images/awards/Kannada_Kanmani_State_Award.jpg',
    name: 'Kannada Kanmani State Award',
  },
  {
    src: '/Images/awards/1.jpg',
    name: 'Sahyadri Varthe 15th June 2016',
  },
  {
    src: '/Images/awards/2.jpg',
    name: 'Vijaya Vani 10th August 2016',
  },
  {
    src: '/Images/awards/3.jpg',
    name: 'Sahyadri Varthe 17th August 2016',
  },
  {
    src: '/Images/awards/4.jpg',
    name: 'Praja Vani 26th September 2016',
  },
  {
    src: '/Images/awards/5.jpg',
    name: 'Chalagara 30th September 2016',
  },
  {
    src: '/Images/awards/6.jpg',
    name: 'Sahyadri Varthe 14th December 2016',
  },
  {
    src: '/Images/awards/paper.jpg',
    name: 'Shrunga Taranga 3rd January 2019',
  },
  
  {
    src: '/Images/awards/7.jpg',
    name: 'Chalagara 22nd March 2019',
  },
  
  // Add more image data as needed
]

const awardsData = [
  {
    title: "Honorary award from Vipra Trust Shivamogga in the hyear 2007",
    year: 2007
  },
  {
    title: "Honorary award from Shivamogga district chamber of commerce and industries in the year 2008.",
    year: 2008
  },
  {
    title: "Excellency Award from the Shivamogga district Commerce association  in the year 2008 on account of Vishweshwarya’s birthday.",
    year: 2008
  },
  {
    title: " Puttur Areca Missionary File award in the year 2009",
    year: 2009
  },
  {
    title: "Honorary award from Department of mechanical engineering, H.M.T.T.C, Tumkur",
    
  },
  {
    title: "Honorary award from Karnataka Brahmana Samaja, Shivamogga.",
    year: 2008
  },
  {
    title: "Honorary award from Thirthahalli Junior chamber and other institutions.",
    
  },
  {
    title: " Honorary award from Bengaluru’s Sahyadri institution for invention of Arecanut dehusking machine.",
   
  },
  {
    title: "Honorary award from Rotary Club, Thirthahalli.",
    
  },
  {
    title: "Honorary award from Hemadri Vividodesha sahakara bank.",
    
  },
  {
    title: " Honorary award from Taluk yuvajana association, Thirthahalli.",
    
  },
  {
    title: " Rewarded Malenadu Saadhaka Prashasti from Malenadu Mitra Vrinda in the year 2016.",
    
  },
  {
    title: "  Abhimaanada Sanmaana award from BJP National President Amit Shah during Arecanut Crop developers conference held on 26th March 2018",
    
  },
  {
    title: " Honoured for the contribution in the field of agriculture from Brahman Mahasabha Hariharapura division on 10th May 2017.",
   
  },
  {
    title: " V-Tech Engineers founder Mr. Vishwanath was felicitated by Rameshwar Co-operative Society for his excellent contribution in agriculture field.",
    
  },
  {
    title: "Honoured with Malenadu prathibha award by Tirthahalli's Yuva Brahmin Association.",
    
  },
  {
    title: "Honoured with Ujwala Udyami award by Karnataka Small Scale Industries Association for the innovation of arecanut dehusking machine and contribution in the field of agriculture.",
   
  },
  {
    title: "A stamp depicting the achievements of V-Tech organization and Mr. Vishwanath in the field of agriculture, was released by Indian Post Office to honour V-Tech organization as well as Mr.Vishwanath.",
    
  },
  {
    title: " Mr. Vishwanath received Most Promising Industrialist award in the KTES 2020 festival held at JNNCE College.",
    
  },
  {
    title: "For standing by the farmers during the period of Coronavirus Lockdown with novel ideas, Yuva Brigade Fifth Pillar awarded and honoured Mr.Vishwanath with Corona Innovation Award.",
    
  },
  // Add the rest of the awards here
];

const Awards = () => {
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  const openLightbox = (index) => {
    setLightboxIndex(index);
    setLightboxOpen(true);
  };
  return (
    <div>
      <Navbar/>
    <div>
      <div className="awards-container">
        <h2>Awards and Recognitions</h2>
        <div className="awards-content">
          <ul className="awards-list">
            {awardsData.map((award, index) => (
              <li key={index} className="award-item">
                <div className="award-title">{award.title}</div>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="additional-content-container">
        
          <h2>KASSIA Ujwala Udyami Award</h2>
        <div className="image-container">
          
          <img src="/Images/awards/award.jpg" alt="Mr. Vishwanath" />
        </div>
        <div className="image-caption">
          <p>
            Famous for his invention of Arecanut Dehusking machine and numerous Agriculture machines, Mr. Vishwanath received Ujwala Udyami 2019 Award from Karnataka Small Scale Industries Association.
          </p>
          <p>
            This Award was sponsored by Suvarna News and Kannada prabha newspaper, Karnataka Small Scale Industries Association [KSSIA], State Bank of India [SBI], Mahindra Jeeto for achievements in Small Scale Industry arena in Karnataka.
          </p>
          <p>
            Felicitation Program was held at KSSIA auditorium staged in Bengaluru’s Vijayanagar. Mr. Vishwanath received Ujwala Udyami 2019 Award for his achievements in the field of Agriculture and Arecanut Dehusking Machine, which was sponsored by State’s one of the finest news channel Suvarna News Channel and Karnataka Small Scale Industries Association and State Bank of India [SBI]. Sri Chakravarthi Sulibele was present as the Chief guest of the felicitation program, whereas Suvarna News’ Ajith Hanumakkanawar, KSSIA board members and State Bank of India Officers were also Present in the program.
          </p>
        </div>
              
        <h2>Image Gallery</h2>
        <div className="image-gallery">
        
          {imagesData.map((image, index) => (
            <div key={index} className="image-item" onClick={() => openLightbox(index)}>
              <img src={image.src} alt={image.name} />
              <div className="image-name">{image.name}</div>
            </div>
          ))}
        </div>
      </div>

      {lightboxOpen && (
        <Lightbox
          mainSrc={imagesData[lightboxIndex].src}
          nextSrc={imagesData[(lightboxIndex + 1) % imagesData.length].src}
          prevSrc={imagesData[(lightboxIndex + imagesData.length - 1) % imagesData.length].src}
          onCloseRequest={() => setLightboxOpen(false)}
          onMovePrevRequest={() =>
            setLightboxIndex((lightboxIndex + imagesData.length - 1) % imagesData.length)
          }
          onMoveNextRequest={() => setLightboxIndex((lightboxIndex + 1) % imagesData.length)}
        />
      )}

      <Footer />
      </div>

    </div>
  );
};

export default Awards;