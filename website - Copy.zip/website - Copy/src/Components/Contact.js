import React, { useState } from 'react';
import Navbar from './Navbar';
import Footer from './Footer';

function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add your form submission logic here (e.g., send data to a server or handle it in some way).
    console.log(formData);
    // Reset the form fields
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: '',
    });
  };

  return (
    <div>
      <Navbar/>
      <div className="About-containera">

    <div className="contact-form-containerc">
      <div className="contact-formc">
        <h2>Contact Us</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-groupc">
            <label htmlFor="name">Name:</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-groupc">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-groupc">
            <label htmlFor="subject">Subject:</label>
            <input
              type="text"
              id="subject"
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-groupc">
            <label htmlFor="message">Message:</label>
            <textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit"><a href="mailto:office@vtechengineer.com">Send Message</a></button>
        </form>
      </div>
      <div className="owner-addressc">
        <div className="cinfoc"><h2>Contact Information</h2></div>
        {/* Add the owner's address here */}
        <address>
        V-Tech Engineers Kuntavalli, Melige Post,
Thirthahalli(Tq), Shivamogga - 577415
          <br /><br/>
          OFFICE NUMBER:<br/>
          08181-272075<br/>
          08181-272175<br/>
          <br/>
          CUSTOMER CARE:<br/>
          94481 05006<br/>
          94482 87796<br/>
          89713 12191<br/>
          08181-295295<br/>
          <br/>
          EMAIL ADDRESS:
          office@vtechengineer.com
        </address>
      </div>
    
      </div>
      <Footer/>
      </div>
      </div>
  );
}

export default Contact;
