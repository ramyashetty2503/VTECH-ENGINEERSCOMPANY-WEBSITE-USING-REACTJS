import React from "react";
// import BannerBackground from "../Assets/home-banner-background.jpeg";
// import BannerImage from "../Assets/home-banner-image.jpeg";
import Navbar from "./Navbar";
import { FiArrowRight } from "react-icons/fi";
import { alignProperty } from "@mui/material/styles/cssUtils";
import { Style } from "@mui/icons-material";
import { colors } from "@mui/material";
import Footer from "./Footer";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // Import carousel styles
import { Carousel } from "react-responsive-carousel";

const carouselImages = [
  {
    src:'/homei/Tree.JPG',
    name:'Tree',
  },
  {
    src:'/homei/green.jpg',
    name:'green',
  },
  {
    src:'/homei/a.png',
    name:'a',
  },
  {
    src:'/homei/adike.jpg',
    name:'a',
  },
  // {
  //   src:'/homei/orange1.jpg',
  //   name:'a',
  // },
      


];

const Home = () => {
  return (
    <div className="home-container">
      <Navbar />
      <div className="About-containera">
      
        <div className="home-text-section">
          <h1 className="primary-heading" >
            V-TECH ENGINEERS
            ಎಂದೆಂದಿಗೂ ನಿಮ್ಮೊಂದಿಗೆ.....

          </h1><br>
          </br>
          <br>
          </br>
          <p className="primary-text" ><strong>India is the country where agriculture plays a vital role in the economy and areca nut has its own significance in agriculture development in India both economically and culturally. Arecanut has not only remained as Commercial crop in Malenadu and some part of North Karnataka, but it is treated as auspicious thing during functions. At one point of time, Arecanut was indispensable part of people life in such a way that, every equipment of home was filled with Arecanut.<br/><br/>

If Areca nut bunch is not detached and segregated into individual areca nut, post 4 days after retrieving it from areca nut tree, there will be major reduction in the quality of same. Also, dearth of skilled man-power was causing hindrance to the areca nut development.<br/><br/>

During the scarcity of skilled man power, there were times where alternative crop for Arecanut was also given a thought and farmers were baffled because of it.<br/><br/>

Onus of finding solution for this problem was on society.

Sri Kuntavalli Vishwanath took this problem as a challenge, since he hails from agricultural background and started inventing Areca nut de husking machine while studying Mechanical Diploma in the year 2001.

After 5 years of perseverance and dedication despite lot of ups and downs, finally invented Areca nut dehusking machine, which was first of its kind in the history. With the aim of serving the farmers he established V-Tech Engineers company in the year 2006. Through V-Tech company, many farmer-friendly products were invented and brought into mainstream. V-Tech company is well-known for areca nut bunch separator machines and always committed in process of inventing farmer-friendly machines.<br/><br/>

Markets of our products are widespread in all the four directions of India, right from Assam to Tamilnadu and Kerala to Andaman. We are in the process of establishing our markets in abroad countries like Sri Lanka and Indonesia. Farmers who have used our company's equipment have appreciated its applications and significance whole-heartedly.<br/><br/>
<div className="underline"><strong >Best services for Precious customers :</strong></div>
vtech engineer Emergency services<br/>
vtech engineer Great Quality<br/>
vtech engineer In touch with farmers always<br/>
vtech engineer Service Centres at each taluk<br/>
vtech engineer Expert employees</strong>
</p><br/><br/> </div>

          <div className="carousel-container">
          <Carousel
            showArrows={true}
            showThumbs={false}
            infiniteLoop={true}
            autoPlay={true}
            interval={3000} // Set the interval (in milliseconds) between slides
          >{carouselImages.map((imageUrl, index) => (
            <div key={index}>
              <img src={imageUrl.src} alt={imageUrl.name} />
            </div>
          ))}</Carousel>
         <div/>
         <br/>
         <br/>

          <button className="secondary-button">
            <a href="https://play.google.com/store/apps/details?id=com.vtechengineer&pcampaignid=web_share">CLICK TO GET MOBILE APP</a><FiArrowRight />{" "}
          </button>
        </div>
        <br/>
        <br/>
        
        
        
        {/* <div className="home-image-section">
          <img src={BannerImage} alt="" />
        </div> */}
      {/* </div> */}
      <Footer/>
      </div>
    </div>
   
  );
};

export default Home;
