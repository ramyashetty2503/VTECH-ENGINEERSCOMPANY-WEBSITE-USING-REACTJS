import React from 'react';
class Imageslider extends Component {
  constructor(props) {
    super(props);
    this.state = {
      images: [
        "/image/bending_machine.jpg",
        './image/cnc_machine_1.jpg',
        './image/cnc_machine_2.jpg',
        './image/fiber_laser_cutting.jpg',
        './image/flasma_cutting.jpg',
        './image/heat_chamber.jpg',
        './image/iron_cutting.jpg',
        './image/laser_cutting_1.jpg',
        './image/lathe_machine.jpg',
        './image/powder_coating.jpg',
        './image/powder_sprayer.jpg',
        './image/rool_bending.jpg',
        './image/vmc_machine.jpg',
      ],
      currentIndex: 0,
    };
  }

  nextSlide = () => {
    this.setState((prevState) => ({
      currentIndex: (prevState.currentIndex + 1) % prevState.images.length,
    }));
  };

  prevSlide = () => {
    this.setState((prevState) => ({
      currentIndex: (prevState.currentIndex - 1 + prevState.images.length) % prevState.images.length,
    }));
  };

  render() {
    const { images, currentIndex } = this.state;
    return (
      <div className="image-slider">
        <div className="slider-container">
          <img src={images[currentIndex]} alt={`Image ${currentIndex + 1}`} />
        </div>
        <button onClick={this.prevSlide}>Previous</button>
        <button onClick={this.nextSlide}>Next</button>
      </div>
    );
  }
}

export default Imageslider;