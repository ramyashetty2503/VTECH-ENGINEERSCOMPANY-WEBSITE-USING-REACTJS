import React from "react";
import logo from "../Assets/logo.jpg";
import { BsTwitter } from "react-icons/bs";
import { BsYoutube } from "react-icons/bs";
import { FaFacebookF, FaInstagram, FaMapMarker } from "react-icons/fa";

const Footer = () => {
  return (
    <div className="footer-wrapper">
      <div className="footer-section-one">
        <div className="footer-logo-container">
          <img src={logo} alt="" />
        </div>
        <div className="footer-icons" color="white">
          <a href="https://twitter.com/EngineersVtech?t=r8QYuNoxU0DVbWm9zVmj7w&s=09"><BsTwitter /></a><br/>
          <a href="https://instagram.com/vtechengineers?igshid=NTc4MTIwNjQ2YQ=="><FaInstagram /></a><br/>
          <a href="https://youtube.com/@vtechengineerskuntavalli9177?si=-yu5jbtVOjUiXX_t"><BsYoutube /></a><br/>
          <a href="https://www.facebook.com/photo/?fbid=329882944924552&set=a.107887540457428"><FaFacebookF /></a>
        </div>
      </div>
      <div className="footer">
        <div className="footer-section-columns">
          <span>SERVICE CENTERS :</span>
          <span>Thirthahalli</span>
          <span>Shivamogga</span>
          <span>Holalkere</span>
          <span>Chennagiri</span>
          <span>Shikaripura</span>
          <span>Davanagere</span>
          <span>K.B Cross</span>
        </div>
        <div className="footer-section-columns">
          <span>CUSTOMER CARE :</span>
          <span><FaMapMarker/>V-Tech Engineers Kuntavalli, <br/>Melige Post,
          Thirthahalli(Tq),Shivamogga - 577415</span>
          <span><a href="tel:08181-295295">08181-295295</a></span>
          <span><a href="tel:9448105006">+91 9448105006</a></span>
          <span><a href="tel:9448287796">+91 9448287796</a></span>
          <span><a href="tel:8971312191">+91 8971312191</a></span>
          <span><a href="mailto:office@vtechengineer.com">office@vtechengineer.com</a></span>
        </div>
        <div className="footer-section-columns">
          <span>Terms & Conditions</span>
          <span>Privacy Policy</span>
        </div>
      </div>
    </div>
  );
};

export default Footer;
