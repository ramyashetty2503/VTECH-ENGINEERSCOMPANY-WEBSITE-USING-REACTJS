// App.js
import React from "react";
import './App.css'
import './Components/Languageoptions.css'
import { Route, Routes, BrowserRouter } from "react-router-dom";
import Home from './Components/Home'
import Products from './Components/Products'
import Footer from "./Components/Footer";
import Navbar from "./Components/Navbar";
import Contact from "./Components/Contact";
import Service from "./Components/Service";
import About from "./Components/About";
import Gallery from "./Components/Gallery";
import Infra from "./Components/Infra";
import Group from "./Components/Group";
import Awards from "./Components/Awards";
import More from "./Components/More";
// import Imageslider from "./Components/ImageSlider";
// import ProductDetails from './Components/ProductDetails'
function App() {
  return (
    <div className="App">
      <BrowserRouter>
          <Routes>
            <Route path="/Navbar" element={<Navbar/>}/>
            <Route index element={<Home/>}/>
            <Route path="/Home" element={<Home/>}/>
            <Route path="/Products" element={<Products/>}/>
            <Route path="/Contact" element={<Contact/>}/>
            <Route path="/Service" element={<Service/>}/>
            <Route path="/About" element={<About/>}/>
            <Route path="/Gallery" element={<Gallery/>}/>
            <Route path="/Group" element={<Group/>}/>
            <Route path="/Awards" element={<Awards/>}/>

            <Route path="/More" element={<More/>}/>


            <Route path="/Infra" element={<Infra/>}/>
            {/* <Route path="/Imageslider" element={<Imageslider/>}/> */}

        
            {/* <Route path="/Products/:productId" element={<ProductDetails/>}/> */}
            <Route path="/Footer" element={<Footer/>}/>
          </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
